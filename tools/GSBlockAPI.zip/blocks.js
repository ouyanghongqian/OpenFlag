Blockly.Blocks['execcode_text'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("执行代码")
            .appendField(new Blockly.FieldTextInput("code"), "code");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['getvarvalue'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("获取变量")
            .appendField(new Blockly.FieldTextInput("hello"), "value");
        this.setOutput(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['waituserinput'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("等待用户操作 识别：")
            .appendField(new Blockly.FieldDropdown([["触摸按键+按键", "0"], ["触摸按键", "1"], ["按键", "2"]]), "name");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['back2gxxksystem'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("运行GxxkSystem")
            .appendField(new Blockly.FieldDropdown([["主界面", "GxxkSystem.main.main()"], ["锁屏界面", "GxxkSystem.main.lockScreen()"], ["插件商店", "GxxkSystem.main.pluginStore()"], ["本地插件", "GxxkSystem.main.localPlugin()"]]), "option");
      this.setInputsInline(false);
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['writepluginconfig'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("写入插件配置")
            .appendField(new Blockly.FieldTextInput("id"), "id");
        this.appendValueInput("data")
            .setCheck("Array")
            .appendField("插件配置");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['getmemfree'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("可用内存");
        this.setOutput(true, "Number");
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['hashstr'] = {
    init: function() {
        this.appendValueInput("value")
            .setCheck(null)
            .appendField("哈希");
        this.setOutput(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['set_insurance_ram_allocation_value'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("设置保险RAM分配为")
            .appendField(new Blockly.FieldNumber(0, 50), "NAME");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['setoptlvl'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("设置编译模式为")
            .appendField(new Blockly.FieldDropdown([["开启", "0"], ["关闭", "1"], ["关闭并不记录行号", "3"]]), "value");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['setheap'] = {
    init: function() {
        this.appendDummyInput()
            .appendField(new Blockly.FieldDropdown([["锁定", "micropython.heap_lock()"], ["解锁", "micropython.heap_unlock()"]]), "NAME")
            .appendField("内存堆");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['set2const'] = {
    init: function() {
        this.appendValueInput("value")
            .setCheck(null)
            .appendField("设置为常量");
        this.setOutput(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['type2bool'] = {
    init: function() {
        this.appendValueInput("value")
            .setCheck(null)
            .setAlign(Blockly.ALIGN_RIGHT)
            .appendField("转布尔值");
        this.setOutput(true, "Boolean");
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['bettervar_edit'] = {
    init: function() {
        this.appendValueInput("value")
            .setCheck(null)
            .appendField("将变量")
            .appendField(new Blockly.FieldTextInput("hello"), "varName")
            .appendField(new Blockly.FieldDropdown([["增加", "+"], ["减少", "-"], ["乘", "*"], ["除以", "/"]]), "method");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['bettervar_set'] = {
    init: function() {
        this.appendValueInput("value")
            .setCheck(null)
            .appendField("将变量")
            .appendField(new Blockly.FieldTextInput("hello"), "varName")
            .appendField("修改为");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['getpluginconfig'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("获取插件配置")
            .appendField(new Blockly.FieldTextInput("id"), "id");
        this.setOutput(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['evalcode'] = {
    init: function() {
        this.appendValueInput("code")
            .setCheck(null)
            .appendField("执行代码");
        this.setOutput(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['betterconnectwifi'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("更好地连接WiFi");
        this.appendValueInput("wifiName")
            .setCheck("String")
            .appendField("WiFi名");
        this.appendValueInput("wifiPwd")
            .setCheck("String")
            .appendField("WiFi密码");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['memcollect'] = {
    init: function() {
        this.appendDummyInput()
            .appendField(new Blockly.FieldDropdown([["进行", "collect()"], ["开启", "enable()"], ["禁用", "disable()"]]), "select")
            .appendField("内存回收");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['importmodule'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("导入模块")
            .appendField(new Blockly.FieldTextInput("module"), "module");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['execcode'] = {
    init: function() {
        this.appendValueInput("code")
            .setCheck("String")
            .appendField("执行代码");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(210);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
