Blockly.Python['execcode_text'] = function(block) {
    var text_code = block.getFieldValue('code');
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = text_code;
    return code;
};
Blockly.Python['getvarvalue'] = function(block) {
    var text_value = block.getFieldValue('value');
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = text_value;
    // TODO: Change ORDER_NONE to the correct strength.
    return [code, Blockly.Python.ORDER_NONE];
};
Blockly.Python['waituserinput'] = function(block) {
    var dropdown_name = block.getFieldValue('name');
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['import_mpython'] = 'from mpython import *';
    Blockly.Python.definitions_['waitFunc'] = 'def wait(mode="0"):\n    modes=["touchPad_P.read()<100 or touchPad_Y.read()<100 or touchPad_T.read()<100 or touchPad_H.read()<100 or touchPad_O.read()<100 or touchPad_N.read()<100","button_a.is_pressed() or button_b.is_pressed()"]\n    if mode=="0":modes=modes[0]+\' or \'+modes[1]\n    elif mode=="1":modes=modes[0]\n    elif mode=="2":modes=modes[1]\n    else:modes=modes[0]+\' or \'+modes[1]\n    while not eval(modes):pass';
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = "wait(mode="+dropdown_name+")";
    return code;
};
Blockly.Python['back2gxxksystem'] = function(block) {
    var dropdown_option = block.getFieldValue('option');
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['GxxkSystemMain'] = 'import GxxkSystem.main';
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = dropdown_option+"\n";
    return code;
};
Blockly.Python['writepluginconfig'] = function(block) {
    var text_id = block.getFieldValue('id');
    var value_data = Blockly.Python.valueToCode(block, 'data', Blockly.Python.ORDER_ATOMIC);
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['GxxkSystemPluginApi'] = 'import GxxkSystemPluginApi';
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = 'GxxkSystem.pluginApi.writePluginConfig("'+text_id+'",'+value_data+')'+"\n";
    return code;
};
Blockly.Python['getmemfree'] = function(block) {
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['gc'] = 'import gc';
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = 'gc.mem_free()';
    // TODO: Change ORDER_NONE to the correct strength.
    return [code, Blockly.Python.ORDER_NONE];
};
Blockly.Python['hashstr'] = function(block) {
    var value_value = Blockly.Python.valueToCode(block, 'value', Blockly.Python.ORDER_ATOMIC);
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = 'hash('+value_value+')';
    // TODO: Change ORDER_NONE to the correct strength.
    return [code, Blockly.Python.ORDER_NONE];
};
Blockly.Python['set_insurance_ram_allocation_value'] = function(block) {
    var number_name = block.getFieldValue('NAME');
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['micropython'] = 'import micropython';
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = 'micropython.alloc_emergency_exception_buf('+number_name+')'+"\n";
    return code;
};
Blockly.Python['setoptlvl'] = function(block) {
    var dropdown_value = block.getFieldValue('value');
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['micropython'] = 'import micropython';
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = 'micropython.opt_level('+dropdown_value+')'+"\n";
    return code;
};
Blockly.Python['setheap'] = function(block) {
    var dropdown_name = block.getFieldValue('NAME');
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['micropython'] = 'import micropython';
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = dropdown_name+"\n";
    return code;
};
Blockly.Python['set2const'] = function(block) {
    var value_value = Blockly.Python.valueToCode(block, 'value', Blockly.Python.ORDER_ATOMIC);
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['micropython'] = 'import micropython';
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = 'micropython.const('+value_value+')';
    // TODO: Change ORDER_NONE to the correct strength.
    return [code, Blockly.Python.ORDER_NONE];
};
Blockly.Python['type2bool'] = function(block) {
    var value_value = Blockly.Python.valueToCode(block, 'value', Blockly.Python.ORDER_ATOMIC);
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = 'bool('+value_value+')';
    // TODO: Change ORDER_NONE to the correct strength.
    return [code, Blockly.Python.ORDER_NONE];
};
Blockly.Python['bettervar_edit'] = function(block) {
    var text_varname = block.getFieldValue('varName');
    var dropdown_method = block.getFieldValue('method');
    var value_value = Blockly.Python.valueToCode(block, 'value', Blockly.Python.ORDER_ATOMIC);
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = text_varname+dropdown_method+'='+value_value+"\n";
    return code;
};
Blockly.Python['bettervar_set'] = function(block) {
    var text_varname = block.getFieldValue('varName');
    var value_value = Blockly.Python.valueToCode(block, 'value', Blockly.Python.ORDER_ATOMIC);
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = text_varname+'='+value_value+"\n";
    return code;
};
Blockly.Python['getpluginconfig'] = function(block) {
    var text_id = block.getFieldValue('id');
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['GxxkSystemPluginApi'] = 'import GxxkSystem.pluginApi';
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = 'GxxkSystem.pluginApi.getPluginConfig("'+text_id+'")';
    // TODO: Change ORDER_NONE to the correct strength.
    return [code, Blockly.Python.ORDER_NONE];
};
Blockly.Python['evalcode'] = function(block) {
    var value_code = Blockly.Python.valueToCode(block, 'code', Blockly.Python.ORDER_ATOMIC);
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = 'eval("'+value_code+'")';
    // TODO: Change ORDER_NONE to the correct strength.
    return [code, Blockly.Python.ORDER_NONE];
};
Blockly.Python['betterconnectwifi'] = function(block) {
    var value_wifiname = Blockly.Python.valueToCode(block, 'wifiName', Blockly.Python.ORDER_ATOMIC);
    var value_wifipwd = Blockly.Python.valueToCode(block, 'wifiPwd', Blockly.Python.ORDER_ATOMIC);
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['import_mpython'] = 'from mpython import *';
    Blockly.Python.definitions_['wifi'] = 'wifi=wifi()';
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = 'wifi.connectWiFi('+value_wifiname+','+value_wifipwd+')'+"\n";
    return code;
};
Blockly.Python['memcollect'] = function(block) {
    var dropdown_select = block.getFieldValue('select');
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['gc'] = 'import gc';
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = 'gc.'+dropdown_select+'\n';
    return code;
};
Blockly.Python['importmodule'] = function(block) {
    var text_module = block.getFieldValue('module');
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = 'import '+text_module+"\n";
    return code;
};
Blockly.Python['execcode'] = function(block) {
    var value_code = Blockly.Python.valueToCode(block, 'code', Blockly.Python.ORDER_ATOMIC);
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['banquan'] = '# 此程序使用了GxxkSystemBlockAPI（缩写GSBlockAPI）或此模块（插件）的修改版';
    var code = "exec("+value_code+")\n";
    return code;
};
